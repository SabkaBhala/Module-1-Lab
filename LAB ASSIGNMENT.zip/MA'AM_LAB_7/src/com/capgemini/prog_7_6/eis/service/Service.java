package com.capgemini.prog_7_6.eis.service;

import java.util.HashMap;
import java.util.Scanner;
import java.util.Set;
import java.util.TreeSet;

import com.capgemini.prog_7_6.eis.bean.Employee;
import com.capgemini.prog_7_6.eis.exception.EmployeeException;

public class Service implements Employeeservice {

	Employee e;
	Scanner sc;
	int id;
	public Employee setdetails() throws EmployeeException {
		sc= new Scanner(System.in);
		System.out.println("enter employee id");
	    id = sc.nextInt();
		System.out.println("enter employee name");
		String name = sc.nextLine();
		name += sc.nextLine();
		System.out.println("enter employee slary");
		int salary = sc.nextInt();
		System.out.println("enter employee designation");
		String desig = sc.nextLine();
		desig += sc.nextLine();
		System.out.println("enter employee scheme");
		String schm = sc.next();
		schm += sc.nextLine();
		e = new Employee(id, name, salary, desig, schm);
		sc.close();
		if (salary < 3000) {
			throw new EmployeeException("salary should be greater than 3000");
		}
		return e;
	}

	@Override
	public void findscheme(int salary, String designation, Employee e) {
		// TODO Auto-generated method stub
		if (designation.equals("System Asssociate") && (salary > 5000 && salary < 20000))
			e.setInsurancescheme("C");
		else if (designation.equals("Programmer") && (salary >= 20000 && salary < 40000))
			e.setInsurancescheme("B");
		else if (designation.equals("Manager") && (salary >= 40000))
			e.setInsurancescheme("A");
		else if (designation.equals("Clerk") && (salary < 5000))
			e.setInsurancescheme("No");
	}

	@Override
	public void getdetails(String str, HashMap<Integer, Employee> map) {
		// TODO Auto-generated method stub
		for (Employee e : map.values()) {
			if (str.equals(e.getInsurancescheme())) {
				System.out.println("Salary is: " + e.getSalary());
				System.out.println("Employee name is: " + e.getName());
				System.out.println("Employee id is: " + e.getId());
				System.out.println("Employee designation is: " + e.getDesignation());
				System.out.println("Employee insurance scheme is: " + e.getInsurancescheme());
			}
		}
	}

	@Override
	public void removeEmployee(int id, HashMap<Integer, Employee> map) {
		// TODO Auto-generated method stub
		map.remove(id);
		System.out.println("\nsuccessfully deleted\n");
	}

	@Override
	public void Sort(HashMap<Integer, Employee> map) {
		Set<Employee> s = new TreeSet<>(map.values());
		System.out.println(s);

	}

}
