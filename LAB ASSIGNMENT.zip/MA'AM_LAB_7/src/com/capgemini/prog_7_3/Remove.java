package com.capgemini.prog_7_3;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class Remove {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
         
         
         ArrayList<String> a=new ArrayList<String>();
         a.add("AMAN");
         a.add("Mittall");
         a.add("sumit");
         a.add("chauhan");
         
         ArrayList<String> b=new ArrayList<String>();
         b.add("sumit");
         b.add("chauhan");
         removeElements(a,b);
         
	}
          public static void removeElements(List<String> a,List<String> b)
          {
          {ArrayList<String> a1=new ArrayList<String>();
          ArrayList<String> a2=new ArrayList<String>();
          a1.addAll(a);
          a2.addAll(b);
          a1.removeAll(a2);
          Iterator<String> i=a1.iterator();
          System.out.println("Remaining elements after removing elements of the second list");
          while(i.hasNext())
          {System.out.println(i.next());
          
          }
          }
          }
}
