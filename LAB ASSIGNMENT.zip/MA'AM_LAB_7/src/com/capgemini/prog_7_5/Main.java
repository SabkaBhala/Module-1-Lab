package com.capgemini.prog_7_5;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

public class Main {
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		int i;
		String s;
		System.out.println("Enter the elements of the list");
		ArrayList<String> a = new ArrayList<String>();
		for (i = 0; i < 5; i++) {
			s = sc.nextLine();
			a.add(s);
		}
		Main u = new Main();
		sc.close();
		u.sortNames(a);
	}

	public void sortNames(List<String> a) {
		Collections.sort(a);
		for (String s : a) {
			System.out.println(s);

		}
	}

}
