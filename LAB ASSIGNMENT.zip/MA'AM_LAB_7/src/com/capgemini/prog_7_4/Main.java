package com.capgemini.prog_7_4;

import java.util.HashMap;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		int a[] = new int[5];
		System.out.println("Enter the elements of the array");
		int i;
		for (i = 0; i < 5; i++) {
			a[i] = sc.nextInt();

		}
		sc.close();
		Main s = new Main();
		HashMap<Integer, Double> h = new HashMap<Integer, Double>();

		h = s.getSquares(a);
		System.out.println(h);
	}

	public HashMap<Integer, Double> getSquares(int a[]) {
		HashMap<Integer, Double> hm = new HashMap<Integer, Double>();
		int i;
		for (i = 0; i < a.length; i++)
			hm.put(a[i], Math.pow(a[i], 2));
		return hm;
	}

}
