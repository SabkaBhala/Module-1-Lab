package com.capgemini.prog3_4;

import java.time.LocalDate;
import java.time.Period;

public class Diffrence2date {

	public static void diff(LocalDate pdate, LocalDate qdate)
	{
		System.out.println(pdate);
		System.out.println(qdate);
	    Period diff = Period.between(pdate, qdate);
	    System.out.printf("\nDifference is %d years", diff.getYears());	
	    System.out.printf("\nDiffrence is %d months",diff.getMonths());
	    System.out.printf("\nDiffrence is %d days",diff.getDays());
	}
	public static void main(String[] args) {
		LocalDate pdate = LocalDate.of(2008, 05, 19);
		LocalDate qdate = LocalDate.of(1999, 10, 20);
		diff(pdate,qdate);
	  }
}
