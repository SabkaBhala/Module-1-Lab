package com.capgemini.prog3_7;

import java.util.Scanner;
import java.util.regex.Pattern;

public class RegexExample {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String s = sc.nextLine();
		if (Pattern.matches("(.){8,}_job", s)) {
			System.out.println("True");
		} else {
			System.out.println("false");
		}
		sc.close();
	}

}
