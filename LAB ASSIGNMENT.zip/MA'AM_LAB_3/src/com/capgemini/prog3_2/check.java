package com.capgemini.prog3_2;

import java.util.Scanner;

public class check {
	
	public static void main(String[] args) {
		String s1;
		int i, c, d, a;
		int flag = 0;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter String : ");
		s1 = sc.nextLine();

		for (i = 0; i < s1.length() - 1; i++) {
			if (s1.charAt(i) < s1.charAt(i + 1))
				continue;
			else {
				flag = 1;
				break;
			}
		}

		if (flag == 1)
			System.out.println(false);
		else
			System.out.println(true);
	}

}
