package com.capgemini.prog3_6;

import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.Scanner;

public class Zonetime {

	public static void zone(String s)
	{
		ZonedDateTime z = ZonedDateTime.now(ZoneId.of(s));
		System.out.println(z);
	}
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		String s=sc.nextLine();
		zone(s);
		sc.close();
	}
}
