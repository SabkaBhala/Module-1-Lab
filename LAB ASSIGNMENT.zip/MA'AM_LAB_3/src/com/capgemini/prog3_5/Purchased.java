package com.capgemini.prog3_5;
import java.time.LocalDate;
import java.time.Period;
import java.util.Scanner;

public class Purchased {

	public static void count(LocalDate qdate, int m, int d)
	{
		LocalDate fdate = qdate.plus(Period.of(0, m, d));
		System.out.println(fdate);
	}
	public static void main(String[] args) {
		LocalDate qdate = LocalDate.of(2008, 10, 15);
		Scanner sc=new Scanner(System.in);
		int m=sc.nextInt();
		int d=sc.nextInt();
		count(qdate,m,d);
		sc.close();
	}
}
