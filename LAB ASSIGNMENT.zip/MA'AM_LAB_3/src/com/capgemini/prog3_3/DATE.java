package com.capgemini.prog3_3;

import java.time.LocalDate;
import java.time.Period;

public class DATE {

	public static void diff(LocalDate HK) {
		LocalDate now = LocalDate.now();
		Period diff = Period.between(HK, now);
		System.out.printf("\nDifference BETWEEN THE YEARS  %d years", diff.getYears());
		System.out.printf("\n Diffrence Between the months %d months",diff.getMonths());
		System.out.printf("\n Diffrence Between the days %d days",diff.getDays());
	}

	public static void main(String[] args) {
		LocalDate HK = LocalDate.of(2018, 12, 12);
		diff(HK);
	}

}
