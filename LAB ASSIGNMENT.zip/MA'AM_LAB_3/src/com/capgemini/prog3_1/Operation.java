package com.capgemini.prog3_1;

import java.util.Scanner;

public class Operation {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter a String");
		String s1 = sc.nextLine();
		String s2 = "";
		String s3 = "";

		int a = s1.length();
		int b, i;
		char c;
		while(true)
		{
		System.out.println("CHOICES");
		System.out.println("1: For adding the string");
		System.out.println("2: for replacing odd place with #");
		System.out.println("3: For removing duplicate character in a string");
		System.out.println("4: for changing the character to upper case");
		System.out.println("Enter your choice: ");

		b = sc.nextInt();

		switch (b) {
		case 1: {
			s2 = s1 + s1;
			System.out.println(s2);
			break;
		}
		case 2: {
			for (i = 0; i < a; i++) {
				if (i % 2 == 0)
					s3 = s3 + "#";
				else
					s3 = s3 + s1.charAt(i);
			}
			System.out.println(s3);
			break;
		}
		case 3: {
			for (i = 0; i < a; i++) {
				c = s1.charAt(i);
				if (s3.indexOf(c) == -1) {
					s3 = s3 + c;
				}
			}
			System.out.println(s3);
			break;
		}
		case 4: {
			for (i = 0; i < a; i++) {
				if (i % 2 == 0)
					s3 = s3 + Character.toUpperCase(s1.charAt(i));
				else
					s3 = s3 + s1.charAt(i);
			}
			System.out.println(s3);
		}

		}
	}

}
}