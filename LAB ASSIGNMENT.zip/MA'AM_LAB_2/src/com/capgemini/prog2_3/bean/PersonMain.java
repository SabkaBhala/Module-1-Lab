package com.capgemini.prog2_3.bean;

public class PersonMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Person obj = new Person("Himanshu", "Kaushik", "M");
		System.out.println("first name :" + obj.getfirstname());
		System.out.println("last name :" + obj.getlastname());
		System.out.println("gender :" + obj.getgender());
		obj.setfirstname("Simran");
		obj.setlastname("Singh");
		obj.setgender("M");
		System.out.println("first name  :" + obj.getfirstname());
		System.out.println("last name  :" + obj.getlastname());
		System.out.println("gender  :" + obj.getgender());
	}

}
