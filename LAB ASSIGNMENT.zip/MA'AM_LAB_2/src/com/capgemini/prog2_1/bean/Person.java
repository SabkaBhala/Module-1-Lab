package com.capgemini.prog2_1.bean;

public class Person {
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("First name: Himanshu");
		System.out.println("last name: Kaushik");
		System.out.println("Gender: M");
		System.out.println("Age: 19");
		System.out.println("Weight: 60");
	}

}
