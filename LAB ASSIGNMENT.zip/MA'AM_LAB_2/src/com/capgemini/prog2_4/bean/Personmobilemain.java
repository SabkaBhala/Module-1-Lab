package com.capgemini.prog2_4.bean;

public class Personmobilemain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Personmob obj = new Personmob("Himanshu", "Kaushik", "M", "7078765557");
		obj.print();
	}

}
