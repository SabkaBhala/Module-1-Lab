package com.capgemini.prog5_3;

public abstract class Account {

	Person accholder;

	public abstract double getBalance();
	public abstract void setBalance(double balance);
	public abstract Person getAccholder();
	public abstract void setAccholder(Person accholder);
	public abstract void deposite(double balance) ;
	public abstract void withdraw(double balance);
	
	
}
