package com.cg.test;

import static org.junit.Assert.*;

import java.util.HashMap;
import java.util.Map;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import bean.Trainer;
import dao.feedbackdao;
import dao.feedbackdaoimpl;

public class TestCases {
	private feedbackdao daoref;
	@Before
	public void setUp()  {
		daoref= new feedbackdaoimpl();
		
	}

	
	@Test                                                                    //this test case will be passed and will not thow any error or any failure 
	public void test() {
		HashMap<Integer, Trainer> map=daoref.getTrainerList();
	for(Map.Entry<Integer, Trainer> m:map.entrySet()) {
		assertTrue(m.getValue().getCourseName().equals("Java"));
		
	}
	}
	
	
	@Test
	public void test1() {                                                    // this test case will not be passed and will thow any error or any failure 
		HashMap<Integer, Trainer> map1=daoref.getTrainerList();       // as i have used assertfalse method but passing a true statement inside it 
	 Trainer tr=	map1.get(41);
	 assertTrue(tr.getName().equals("Smitha"));
		
		
	}
		
	
	@After
	public void tearDown()  {
		daoref= null;
		
	}
}