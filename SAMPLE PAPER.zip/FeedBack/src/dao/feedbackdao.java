package dao;

import java.util.HashMap;

import bean.Trainer;

public interface feedbackdao {

	public void addFeedback(Trainer trainer);
	public HashMap<Integer,Trainer> getTrainerList();
}
