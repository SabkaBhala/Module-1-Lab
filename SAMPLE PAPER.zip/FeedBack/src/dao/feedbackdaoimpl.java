package dao;

import java.util.HashMap;

import bean.Trainer;
import util.DBUtil;

public class feedbackdaoimpl implements feedbackdao {

	@Override
	public void addFeedback(Trainer trainer) {

		int id = (int) (Math.random() * 1000);
		DBUtil.feedbackList.put(id, trainer);      //this statement is used to put the entry in a map defined in util calss
													// and the key is generated randomly and we are passing a trainer object as a value. 			

	}

	@Override
	public HashMap<Integer, Trainer> getTrainerList() {
		return DBUtil.feedbackList;         // this will call a map from util class and as the method 
	} 										//declared inside it is static so we are calling it by class name.	

}
