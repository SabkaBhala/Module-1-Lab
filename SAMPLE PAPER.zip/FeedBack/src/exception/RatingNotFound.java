package exception;

public class RatingNotFound extends Exception {

	public RatingNotFound(String message) {

	System.out.println(message);
	}

}
