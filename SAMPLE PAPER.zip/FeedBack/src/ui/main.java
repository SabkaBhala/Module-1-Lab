package ui;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

import bean.Trainer;
import exception.RatingNotFound;
import service.FeedbackServiceIMPL;
import service.IFeedbackService;

public class main {

	public static void main(String[] args) throws RatingNotFound {

		IFeedbackService service = new FeedbackServiceIMPL();
		Map<Integer, Trainer> maps = new HashMap<Integer, Trainer>();

		Scanner sc = new Scanner(System.in);

		System.out.println("enter your choice");
		System.out.println("1. add the details");
		System.out.println("2. Search by rating ");

		int n = sc.nextInt();
		switch (n) {
		case 1: {

			System.out.println("Enter trainer name ");
			String name = sc.next();

			System.out.println("Enter course name ");
			String cname = sc.next();

			System.out.println("Enter the startDate ");
			String sdate = sc.next();

			System.out.println("Enter the endDate ");
			String edate = sc.next();

			System.out.println("Enter trainer rating ");
			int rating = Integer.parseInt(sc.nextLine());

			maps = service.getTrainerList();
			Trainer t = new Trainer(name, cname, sdate, edate, rating);
			service.addFeedback(t);
			maps = service.getTrainerList();
			for (Map.Entry<Integer, Trainer> m : maps.entrySet()) {
				System.out.println(m.getKey() + " " + m.getValue());

			}
			break;
		}

		case 2: {
			maps = service.getTrainerList();
			int f=0;
			System.out.println("Enter rating");
			int r = sc.nextInt();
			// Validation
			if (r >= 1 && r <= 5) {
				// for each loop
				for (Map.Entry<Integer, Trainer> m : maps.entrySet()) {
					if (m.getValue().getRating() == r) {
						f=1;
						System.out.println(m.getKey() + " " + m.getValue());
					}

				}
			}
			if (f==0) {
				throw new RatingNotFound("Rating doesn't exist");
			}
			}
		}
		}

	}
