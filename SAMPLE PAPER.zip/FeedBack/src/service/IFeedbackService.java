package service;

import java.util.HashMap;

import bean.Trainer;

public interface IFeedbackService {
	
	public void addFeedback(Trainer trainer);
	public HashMap<Integer,Trainer> getTrainerList();
}
