package service;

import java.util.HashMap;

import bean.Trainer;
import dao.feedbackdaoimpl;
import dao.feedbackdao;

public class FeedbackServiceIMPL implements IFeedbackService {
	
	feedbackdao hk=new feedbackdaoimpl();
			
		
		@Override
		public HashMap<Integer, Trainer> getTrainerList() {
			return hk.getTrainerList();
		}
		
		@Override
		public void addFeedback(Trainer trainer) {
			// TODO Auto-generated method stub
			hk.addFeedback(trainer);
			
		}
	}

	