package com.capgemini.takehome.exceptions;

public class PRODUCTNOTFOUND extends Exception {

}
