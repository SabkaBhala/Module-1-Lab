package com.capgemini.takehome.ui;

import java.util.Scanner;

import com.capgemini.takehome.bean.Product;
import com.capgemini.takehome.exceptions.PRODUCTNOTFOUND;
import com.capgemini.takehome.service.IProductService;
import com.capgemini.takehome.service.ProductService;

public class Client {

	public static void main(String[] args) throws PRODUCTNOTFOUND {
		// TODO Auto-generated method stub

		IProductService ips = new ProductService() ;

		
		Scanner sc = new Scanner(System.in);
		int n;
		int productCode;
		int Quantity;

	 
			System.out.println("-------------------Menu-------------------");
			System.out.println("1. Generate bill by entering Product code and Quantity");
			System.out.println("2.Exit");
			System.out.println("Enter your Choice");

			n = sc.nextInt();
			sc.nextLine();
			switch (n) {

			case 1:{
				System.out.println("Enter the product code");
				productCode = sc.nextInt();

				System.out.println("Enter the Quantity");
				Quantity = sc.nextInt();

				if (ips.getProductDetails(productCode) != null) {
					System.out.println("Your Quantity is " + Quantity + "Now your Bill is "
							+ ips.getProductDetails(productCode).getProduct_price() * Quantity);}
				

				break;
			}
			case 2:{
				sc.close();
				System.exit(0);
				break;}
			

			}
		}

	}


