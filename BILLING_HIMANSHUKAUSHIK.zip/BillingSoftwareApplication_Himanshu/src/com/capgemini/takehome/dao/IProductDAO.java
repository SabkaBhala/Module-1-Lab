package com.capgemini.takehome.dao;

import com.capgemini.takehome.bean.Product;

// Creating an interface named as IProductDAO
public interface IProductDAO {
	
	 Product getProductDetails(int productCode);

	
	
}
