package com.capgemini.takehome.service;

import com.capgemini.takehome.bean.Product;
import com.capgemini.takehome.dao.IProductDAO;
import com.capgemini.takehome.dao.ProductDAO;

// This class ProductService is implemented by the interface IproductService
public class ProductService implements IProductService {
	
	IProductDAO iproductDao = new ProductDAO();
	
	
	@Override
	public Product getProductDetails(int productCode) {
		// TODO Auto-generated method stub
		return iproductDao.getProductDetails(productCode);
	}
	
	
}
